module.exports = {
    "extends": "standard",
    "globals": {
        "Blob": true,
        "URL": true,
        "Apex": true,
        "screen": true
    }
};